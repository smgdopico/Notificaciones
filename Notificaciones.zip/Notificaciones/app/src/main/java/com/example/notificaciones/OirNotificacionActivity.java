package com.example.notificaciones;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;
import com.example.notificaciones.MainActivity.*;

import java.io.IOException;

import static com.example.notificaciones.MainActivity.NOTIFICACION_ID;
import static com.example.notificaciones.MainActivity.rutaSalida;

public class OirNotificacionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oir_notificacion);


        //para que se quite la notificacion
        NotificationManagerCompat notificationCompat= NotificationManagerCompat.from(getApplicationContext());
        notificationCompat.cancel(NOTIFICACION_ID);

        //todo *******************************************************************************************
        Button bReproducir=findViewById(R.id.bReproducir);
        bReproducir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MediaPlayer mediaPlayer=new MediaPlayer();
                try{
                    mediaPlayer.setDataSource(rutaSalida);
                    mediaPlayer.prepare();
                }catch (IOException e){}
                mediaPlayer.start();
                Toast.makeText(getApplicationContext(),"Reproduciendo audio ",Toast.LENGTH_SHORT).show();
            }
        });
//todo `prueba para reproducir audio
        Button bAudio=findViewById(R.id.bAudio);
        bAudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MediaPlayer m=MediaPlayer.create(getApplicationContext(),R.raw.little_boy);
                m.start();
            }
        });



     /*   ImageButton b=findViewById(R.id.bEscucha);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    MediaPlayer mediaPlayer=new MediaPlayer();
                    try{
                        mediaPlayer.setDataSource(rutaSalida);
                        mediaPlayer.prepare();
                    }catch (Exception e){
                        Toast.makeText(getApplicationContext(),"Error",Toast.LENGTH_SHORT).show();
                    }
                    mediaPlayer.start();
                    Toast.makeText(getApplicationContext(),"Reproducioendo ",Toast.LENGTH_SHORT).show();
            }
        });*/
    }
}