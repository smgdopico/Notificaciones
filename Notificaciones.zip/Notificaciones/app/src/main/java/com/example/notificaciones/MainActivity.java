package com.example.notificaciones;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.io.IOException;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    //todo variable pending
    private PendingIntent pendingIntent;
    //todo hay que crear el nombre del canal y la id del canal
    public final static String CHANNEL_ID = "notificacion";
    public final static int NOTIFICACION_ID = 1;
    //variables de fechas
    int dia1, mes1, año1, hora1, minutos1;
    private String fechaString;
    private Calendar fecha = Calendar.getInstance();
    ;
    // variable de alarmas
    public AlarmManager alarmManager;
    public static final String ALARMA = "alarma";


    //todo variables de la grabacion
    public MediaRecorder grabacion;
    public static String rutaSalida = null;
    int grabacionContador = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //todo necesita estas lineas de codigo para trabajar con los permisos de grabar guardar etc si no no funciona y lo ponemos ne el main pq si no los permite
        // esta app no vale para de nada
        if (ContextCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
                PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(getApplicationContext(),
                        Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            //todo esto pide escribir y grabar
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.RECORD_AUDIO}, 1000);
        }
  /*      final TextView txt = findViewById(R.id.txt);
        String x;

        CalendarView calendario = findViewById(R.id.calendario);
        calendario.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int dayOfMonth) {
                txt.setText(" " + year + "- " + month + "- " + dayOfMonth);

            }
        });
*/
        gestion();
        //AlarmManager alarma manager despierta mi app y me muestra mi notificacion coger el sonido como se pueda y oirlo
        // //SharedPreferences para guarda  valor que el nombre que invento y ruta sonido
    }


    private void gestion() {

        Button bAlarma = findViewById(R.id.bAlarma);
        bAlarma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                crearAlarma(fechaString, hora1, minutos1, fecha);
            }
        });


//TODO GRABAR
        //todo /*Si desea obtener la ruta de su aplicación, use la getFilesDir()que le dará la ruta /data/data/your package/files
        //todo Puede obtener la ruta usando la Environmentvar de su data/packageusando el
        //todo getExternalFilesDir(Environment.getDataDirectory().getAbsolutePath()).getAbsolutePath(); que devolverá la ruta desde el directorio raíz
        // de su almacenamiento externo como /storage/sdcard/Android/data/your pacakge/files/data
        //todo Para acceder a los recursos externos, debe proporcionar el permiso de WRITE_EXTERNAL_STORAGEy READ_EXTERNAL_STORAGEen su manifiesto.
        //todo <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
        //todo <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>*/

        final Button bRec = findViewById(R.id.bRec);
        bRec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (grabacion == null) {
                    rutaSalida = getFilesDir() + "/grabacion.mp3" + grabacionContador++;
                    //rutaSalida=Environment.getDataDirectory().getAbsolutePath();
                    //  rutaSalida = Environment.getExternalStorageDirectory().getAbsolutePath() + "/grabacion.mp3";
                    grabacion = new MediaRecorder();
                    grabacion.setAudioSource(MediaRecorder.AudioSource.MIC);
                    grabacion.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);//captura
                    grabacion.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);//tranforma
                    grabacion.setOutputFile(rutaSalida);//archivo de salida
                    try {
                        grabacion.prepare();
                        grabacion.start();

                    } catch (IOException e) {
                    }
                    bRec.setBackgroundResource(R.drawable.rec);
                    Toast.makeText(getApplicationContext(), "Grabando", Toast.LENGTH_SHORT).show();
                } else if (grabacion != null) {
                    grabacion.stop();
                    grabacion.release();
                    grabacion = null;
                    bRec.setBackgroundResource(R.drawable.stop_rec);
                    Toast.makeText(getApplicationContext(), "Grabacion finalizada ", Toast.LENGTH_SHORT).show();
                }
            }
        });

//todo *************************************************************************************
        // <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    /*            fMediaRecorder= new MediaRecorder();
        fMediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        fMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.AMR_NB);
        fMediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        fMediaRecorder.setAudioChannels(1);
        fMediaRecorder.setAudioSamplingRate(8000);

     //   fMediaRecorder.setOutputFile(fTmpFile.getAbsolutePath());
     //   fMediaRecorder.prepare();
        fMediaRecorder.start();*/
//todo **************************************************************************************


        final EditText txtF = findViewById(R.id.txtF);
        final EditText txtH = findViewById(R.id.txtH);
        //todo/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        final Button f = findViewById(R.id.bHora);
        f.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar x = Calendar.getInstance();
                hora1 = x.get(Calendar.HOUR_OF_DAY);
                minutos1 = x.get(Calendar.MINUTE);
                TimePickerDialog dd = new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int horaDia, int minDia) {
                        txtH.setText(horaDia + " : " + minDia);
                        fecha.set(Calendar.HOUR_OF_DAY, horaDia);
                        fecha.set(Calendar.MINUTE, minDia);
                    }
                }, hora1, minutos1, true);
                dd.show();
            }
        });

        Button h = findViewById(R.id.bFecha);
        h.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar c = Calendar.getInstance();
                dia1 = c.get(Calendar.DAY_OF_MONTH);
                mes1 = c.get(Calendar.MONTH);
                año1 = c.get(Calendar.YEAR);
                DatePickerDialog dd = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                        txtF.setText(String.valueOf(day) + " " + String.valueOf(month) + " " + String.valueOf(year));
                        fecha.set(year, month, day);
                        fechaString = day + "/" + month + "/" + year;
                    }
                }, año1, mes1, dia1);
                dd.show();
            }
        });
        //todo/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        Button bCrear = findViewById(R.id.bCrear);
        bCrear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //todo creamos un metodo para que abra la 2 activity cuando pulsemos en la alerta
                //todo OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                // crearAlarma(fechaString, hora1, minutos1, fecha);
                //todo OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                //abreCtivityEscuhar();
                //TODO TENEMOS QUE CREAR ESTE METODO PORQUE NUESTRA VERSION ES SUPERIOR A LA O Y SI NO NO HACE NADA
                //TODO Y LA PONEMOS ANTES DEL METODO DE ABAJO PORQUE SI NO ES SUPERIOR NO ENTRARA EN EL IF DEL METODO Y SI NO ENTRA Y LUEGO EJECUTA TODO
              /*  creacionCANALNotificacionSuperiorOreo();
                creaNotificacion();*/
            }
        });
    }

    //TODO CREAR LAS ALERTAS DEL MOVIL
    private PendingIntent abreCtivityEscuhar() {
/*  creacionCANALNotificacionSuperiorOreo();
                    creaNotificacion();
                    */
        //todo creamos un intent para ir a nuestra segunda pantalla cuando pulsemos en el icono
        Intent intent = new Intent(getApplicationContext(), OirNotificacionActivity.class);
        //todo hacemos que si el usuario le da atras vaya a nuestro main o se saldra de app
        TaskStackBuilder taskStackBuilder = TaskStackBuilder.create(this);
        //todo le decimos que pantalla queremos que lo haga
        taskStackBuilder.addParentStack(OirNotificacionActivity.class);
        //todo le pasamos el intent
        taskStackBuilder.addNextIntent(intent);
        //todo y luego a nuestra variable pending le decimos que coja el taskt y le pasamos esos dos parametros
        //pendingIntent= taskStackBuilder.getPendingIntent(1,PendingIntent.FLAG_UPDATE_CURRENT);
        //devuelvo el pending intent que acabo de crear
        return taskStackBuilder.getPendingIntent(1, PendingIntent.FLAG_UPDATE_CURRENT);

    }

    //todo LE DAMOS FORMA A LA NOTIFICACION COLORES Y DE MAS HISTORIAS, SI LA VERSION ES ANTERIOR A OREO SE EJECUTARA NORMAL SI NO NO FUNCIONARA
    private void creaNotificacion() {
        //TODO CREAMOS LA NOTIFICACION Y LE PASAMOS EL NANAL
        NotificationCompat.Builder contructor = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_ID);
        //TODO CREAMOS EL ICONO QUE APARECERA
        contructor.setSmallIcon(R.drawable.ic_baseline_hearing_24);
        //TODO CREAMOS EL TITUTLO Y EL CONTENIDO QUE QUEREMOS QUE APAREZCAN
        contructor.setContentTitle("Nota de audio");
        contructor.setContentText("Se borrara despues de oirlo");
        //TODO LE PONEMOS UN COLOR PARA QUE QUEDE BONITO
        contructor.setColor(Color.RED);
        //TODO LE DAMOS UNA PRIORIDAD, AUNQUE NO ES NECESARIO
        contructor.setPriority(NotificationCompat.PRIORITY_MAX);
        //TODO LE PONEMOS UNA LUCECITA DE ALERTA PASANDO EL CORLOR Y LOS SEGUNDOS
        contructor.setLights(Color.RED, 1000, 1000);
        //TODO VIVRACION aunq en el emulador no se ve queda mas pofesiona
        contructor.setVibrate(new long[]{1000, 1000, 1000});
        //TODO ESTO VALE PARA PONER UN SONIDO POR DEFECTO O CREANDO UNA CARPETA CON SONIDOS LE PASAMOS EL NUESTRO
        //TODO QUIZAS PUEDA HACER QUE AL LLEGAR LA NOTIFICACION SE ESCUCHE DIRECTAMENTE CON ESTE PARAMETRO.
        contructor.setDefaults(Notification.DEFAULT_SOUND);

//todo esto hay que ponerlo para cuando le demos a la notificacion abra nuestra activity 2
        //todo al contructor le ponemos el content inten y nuestra variable pending
        //contructor.setContentIntent(pendingIntent);
        //llamando directamente el pending intent que devolvemos de arriba
        contructor.setContentIntent(abreCtivityEscuhar());
        //TODO AHOPRA CREMOS LA VARIABLE
        NotificationManagerCompat notificationCompat = NotificationManagerCompat.from(getApplicationContext());
        notificationCompat.notify(NOTIFICACION_ID, contructor.build());

    }

    //todo SI SON VERSIONES ANTERIORES ESTO NO SE EJECUTA SI SON POSTERIORES A O SI
    private void creacionCANALNotificacionSuperiorOreo() {
        //TODO SI LA VERSION DEL SDK ES SUPERIOR O IGUAL A O HACES LO SIGUIENTE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            //TODO HAY QUE CREAR UN NOMBRE PARA EL CANAL
            CharSequence nombre = "Notificacion";
            //todo y aqui le pasamos nuestro canal nuestro nombre que acabamos de crear y la importancia de las notificaciones en mi caso alto que vale 4segundos
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, nombre, NotificationManager.IMPORTANCE_HIGH);
            //todo creamos el manager lo casteamos y cogemos el recurso del sistema
            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            //todo creamos el canal con nuestra notificacion
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }


    // TODO ------------------------------------------------------------------------------------------------------------------------------------------
    //TODO CREAR LAS ALARMAS PARA LINKAR A LAS NOTIFICACIONES

    public void crearAlarma(final String fechaString, final int hora, int min, final Calendar fecha) {

        boolean banderita = true;
        if (fechaString.isEmpty()) {
            Toast.makeText(getApplicationContext(), "No ha seleecionado fecha", Toast.LENGTH_SHORT).show();
            banderita = false;
        }
        if (hora1 == -1 || hora1 > 24) {
            Toast.makeText(getApplicationContext(), "No ha seleecionado una hora correcta", Toast.LENGTH_SHORT).show();
            banderita = false;
        }
        if (minutos1 == -1 || minutos1 > 59) {
            Toast.makeText(getApplicationContext(), "No ha seleecionado los minutos correctamente", Toast.LENGTH_SHORT).show();
            banderita = false;
        }
        //todo falta comprobar la grabacion que no se como se hace.................
        //todo void	setAlarmClock(AlarmManager.AlarmClockInfo info, PendingIntent operation)
        // todo Programe una alarma que represente un despertador, que se utilizará para notificar al usuario cuando suene.

        //todo  void	setAndAllowWhileIdle(int type, long triggerAtMillis, PendingIntent operation)
        // todo Me gusta set(int, long, android.app.PendingIntent), pero esta alarma podrá ejecutarse incluso cuando el sistema esté inactivo de baja potencia (también conocido como

        //todo void	setExact(int type, long triggerAtMillis, PendingIntent operation)
        //todo Programe una alarma para que se envíe con precisión a la hora indicada.
        //https://developer.android.com/reference/android/app/AlarmManager#setAlarmClock(android.app.AlarmManager.AlarmClockInfo,%20android.app.PendingIntent)
        //todo Este método es parecido setExact(int, long, android.app.PendingIntent), pero implica RTC_WAKEUP.
        // set(int, long, android.app.PendingIntent), pero esta alarma podrá ejecutarse incluso cuando el sistema esté en modo inactivo de bajo consumo
        if (banderita) {

            AlarmManager alarmManager = (AlarmManager) getApplicationContext().getSystemService(ALARM_SERVICE);
            //esto es un intent tçy devuelve un penguing intent de esos abreCtivityEscuhar();
            Intent i = new Intent(MainActivity.this, MostrarNotificacionService.class);
            PendingIntent pi = PendingIntent.getService(MainActivity.this, 0, i, 0);
            alarmManager.setAlarmClock(new AlarmManager.AlarmClockInfo(fecha.getTimeInMillis(), pi), pi);

            //todo TIEMPO REAL DESDE 1970 + 2000 QUE SON 2 SEGUNDOS Calendar.getInstance().getTime().getTime()+2000
            //todo no se pasarme mi fecha guardada
            //todo ªªªªªªªªªªªªªªªªªªªªªªªªªªªªªªªªªªªªªªªªªªªªªª\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ªªªªªªªªªªªªªªªªªª
            //  ((AlarmManager)getSystemService(ALARM_SERVICE)).set(AlarmManager.RTC_WAKEUP, Long.parseLong(fechaString+hora1+minutos1),abreCtivityEscuhar());
            //  crearAlarma(fechaString, hora1, minutos1);

        } else {
            Toast.makeText(getApplicationContext(), "faltan datos para establecer la alarma", Toast.LENGTH_SHORT).show();
        }

    }

/*
*  public static void setAlarm(int i, Long timestamp, Context ctx) {
        AlarmManager alarmManager = (AlarmManager) ctx.getSystemService(ALARM_SERVICE);
        Intent alarmIntent = new Intent(ctx, AlarmReceiver.class);
        PendingIntent pendingIntent;
        pendingIntent = PendingIntent.getBroadcast(ctx, i, alarmIntent, PendingIntent.FLAG_ONE_SHOT);
        alarmIntent.setData((Uri.parse("custom://" + System.currentTimeMillis())));
        alarmManager.set(AlarmManager.RTC_WAKEUP, timestamp, pendingIntent);
    }
* */

}
